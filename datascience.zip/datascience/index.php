<?php
 $con = new MongoClient();
 $db = $con->cenima;
 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>

</body>
</html>