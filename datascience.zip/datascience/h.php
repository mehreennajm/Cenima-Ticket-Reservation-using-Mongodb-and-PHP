
<?php
$o = new MongoClient();


?><!DOCTYPE html>
<html>
<head>
	<title>fds</title>
</head>
<body>

</body>
</html>